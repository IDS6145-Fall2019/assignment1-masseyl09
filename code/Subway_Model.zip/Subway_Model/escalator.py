class escalator:
    ''' A escalator class '''

    def __init__(self):
        self.length = 60
        print("initialization of class escalator")