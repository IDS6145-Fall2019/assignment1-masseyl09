from standingPatron import standingPatron
from walkingPatron import walkingPatron
from escalator import escalator

''' main '''


class station:

def stationCreate(self):
    standingPatron()
    walkingPatron()
    escalator()
    print("initialized a station class")

def main():
    stationCreate()

if __name__ == "__main__":
    main()