class patron:
    ''' A patron class '''

    def __init__(self):
        print("initialization of class patron")



