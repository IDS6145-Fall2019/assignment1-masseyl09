from patron import patron

class standingPatron(patron):
    '''This is a standing patron'''
    def __init__(self):
        self.speed = 0
        patron.__init__()
        print("initialize a standing patron class")


