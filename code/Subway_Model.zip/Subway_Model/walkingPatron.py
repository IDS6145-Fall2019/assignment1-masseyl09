from patron import patron

class walkingPatron(patron):
    '''This is a walking patron'''
    def __init__(self):
        self.speed = 2
        patron.__init__()
        print("initialize a walking patron class")